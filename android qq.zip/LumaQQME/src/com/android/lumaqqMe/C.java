package com.android.lumaqqMe;

import android.view.Menu;

public final class C {
	public static final class id {
		public static final int LOGIN_ID = Menu.FIRST;
		public static final int EXIT_ID = Menu.FIRST + 1;
		public static final int MSG_INFO_ID = 0;
		public static final int MSG_GROUP_ID = 1;
		public static final int MSG_CLUSTER_ID = 2;
		public static final int DIALOG_LOGIN = 1;
	}
}
