package com.android.lumaqqMe.events;

import java.util.LinkedList;
import java.util.Queue;

import android.os.Handler;
import android.os.Message;

import edu.tsinghua.lumaqq.qq.events.IQQListener;
import edu.tsinghua.lumaqq.qq.events.QQEvent;

public class BaseQQListener implements IQQListener {
	private Queue<QQEvent> queue;

	private QQEvent getEvent() {
		synchronized (queue) {
			return queue.poll();
		}
	}

	private void addEvent(QQEvent e) {
		synchronized (queue) {
			queue.offer(e);
		}
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			QQEvent e = getEvent();
			OnQQEvent(e);
		}
	};

	protected void OnQQEvent(QQEvent e) {
	}

	public BaseQQListener() {
		queue = new LinkedList<QQEvent>();
	}

	@Override
	public void qqEvent(QQEvent e) {
		// TODO Auto-generated method stub
		addEvent(e);
		handler.sendEmptyMessage(0);
	}

}
