package com.android.lumaqqMe.jobs;

/**
 * 任务执行器接口
 * 
 * @author luma
 */
public interface IExecutor {
	/**
	 * 添加一个任务
	 * 
	 * @param job
	 */
	public void addJob(IJob job);

	/**
	 * 执行
	 */
	public void execute();

	/**
	 * 添加事件监听器
	 * 
	 * @param lis
	 *            监听器
	 */
	public void addExecutorListener(IExecutorListener lis);

	/**
	 * @return 所有的任务个数
	 */
	public int getAllJobCount();

	/**
	 * @return true表示这个任务执行器的execute方法只会在完成时返回
	 */
	public boolean isBlocked();

	/**
	 * 设置是否在任务队列为空时退出
	 * 
	 * @param exitOnEmpty
	 */
	public void setExitOnEmpty(boolean exitOnEmpty);
}
