package com.android.lumaqqMe.jobs;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import com.android.lumaqqMe.MainShell;
import com.android.lumaqqMe.events.BaseQQListener;

public abstract class AbstractJob extends BaseQQListener implements IJob {
	protected boolean finished;
	protected int myQQ;
	protected IJob fail;
	protected IJob success;
	protected String errorMessage;
	protected MainShell main;
	protected List<IJobListener> listeners;
	protected IProgressMonitor monitor;
	protected int exitCode;

	protected static final int SUCCESS = 0;
	protected static final int TIMEOUT = 1;
	protected static final int FAIL = 2;

	/**
	 * 构造函数
	 */
	public AbstractJob() {
		listeners = new ArrayList<IJobListener>();
		exitCode = SUCCESS;
	}

	/**
	 * 触发任务成功事件
	 * 
	 * @param e
	 */
	protected void fireJobSuccessEvent(JobEvent e) {
		for (IJobListener lis : listeners)
			lis.jobSuccess(e);
	}

	/**
	 * 触发任务失败事件
	 * 
	 * @param e
	 */
	protected void fireJobFailEvent(JobEvent e) {
		for (IJobListener lis : listeners)
			lis.jobFailed(e);
	}

	@Override
	public void addJobListener(IJobListener lis) {
		// TODO Auto-generated method stub
		listeners.add(lis);
	}

	@Override
	public String getErrorString() {
		// TODO Auto-generated method stub
		return errorMessage;
	}

	@Override
	public IJob getFailLink() {
		// TODO Auto-generated method stub
		return fail;
	}

	@Override
	public Object getLinkArgument() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IJob getSuccessLink() {
		// TODO Auto-generated method stub
		return success;
	}

	@Override
	public boolean isSuccess() {
		// TODO Auto-generated method stub
		return exitCode == SUCCESS;
	}

	@Override
	public void prepare(MainShell m) {
		// TODO Auto-generated method stub
		this.main = m;
		finished = false;
		myQQ = main.getClient().getUser().getQQ();
	}

	@Override
	public void run(IProgressMonitor m) throws InvocationTargetException,
			InterruptedException {
		if (!canRun())
			return;

		monitor = m;

		preLoop();
		loop();
		postLoop();
	}

	/**
	 * 在循环前调用
	 */
	protected void preLoop() {
	}

	/**
	 * 在循环结束后调用
	 */
	protected void postLoop() {
	}

	/**
	 * @return true表示任务执行的条件已经具备，false表示不具备。
	 */
	protected boolean canRun() {
		return true;
	}

	/**
	 * 循环
	 */
	protected void loop() {
		synchronized (this) {
			while (!finished && main.getClient().getUser().getQQ() == myQQ
					&& main.getClient().getUser().isLoggedIn()) {
				try {
					this.wait(getInterval());
					if (monitor != null)
						if (monitor.isCanceled())
							break;
				} catch (InterruptedException e) {
				}
				onLoop();
			}
		}
	}

	/**
	 * 循环时调用
	 */
	protected void onLoop() {
	}

	/**
	 * 循环睡眠时间
	 * 
	 * @return
	 */
	protected long getInterval() {
		return 2000;
	}

	/**
	 * 唤醒任务线程，使其返回
	 */
	protected void wake() {
		synchronized (this) {
			try {
				this.wait(1000);
				finished = true;
				notify();
			} catch (InterruptedException e) {
			}
		}
	}

	@Override
	public void setFailLink(IJob job) {
		// TODO Auto-generated method stub
		fail = job;
	}

	@Override
	public void setLinkArgument(Object arg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSuccessLink(IJob job) {
		// TODO Auto-generated method stub
		success = job;
	}
}
