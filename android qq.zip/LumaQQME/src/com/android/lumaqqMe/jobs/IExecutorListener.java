package com.android.lumaqqMe.jobs;

/**
 * 任务执行器事件监听器
 * 
 * @author luma
 */
public interface IExecutorListener {
	public void allCompleted();
}
