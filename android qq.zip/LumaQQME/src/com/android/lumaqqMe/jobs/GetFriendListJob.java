package com.android.lumaqqMe.jobs;

import com.android.lumaqqMe.MainShell;
import com.android.lumaqqMe.R;
import com.android.lumaqqMe.models.GroupType;
import com.android.lumaqqMe.models.ModelUtils;
import com.android.lumaqqMe.models.User;

import edu.tsinghua.lumaqq.qq.QQ;
import edu.tsinghua.lumaqq.qq.beans.QQFriend;
import edu.tsinghua.lumaqq.qq.events.QQEvent;
import edu.tsinghua.lumaqq.qq.packets.OutPacket;
import edu.tsinghua.lumaqq.qq.packets.in.GetFriendListReplyPacket;

public class GetFriendListJob extends AbstractJob {

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		main.getClient().removeQQListener(this);
	}

	@Override
	public void prepare(MainShell m) {
		// TODO Auto-generated method stub
		super.prepare(m);
		main.getClient().addQQListener(this);
	}

	@Override
	public boolean isSuccess() {
		// TODO Auto-generated method stub
		return errorMessage != null;
	}

	@Override
	protected void preLoop() {
		// TODO Auto-generated method stub
		if (monitor != null) {
			monitor.beginTask("", 100);
			monitor.subTask(main.getText(R.string.job_get_friend_list)
					.toString());
		}

		main.getClient().user_GetList();
	}

	@Override
	protected void postLoop() {
		// TODO Auto-generated method stub
		main.getUIHelper().refreshAll();
		if (monitor != null)
			monitor.done();
	}

	/**
	 * 处理得到好友列表成功事件
	 */
	private void processGetFriendListSuccess(QQEvent e) {
		GetFriendListReplyPacket packet = (GetFriendListReplyPacket) e
				.getSource();
		for (QQFriend friend : packet.friends) {
			User u = ModelUtils.createUser(friend);
			main.getUIHelper().addUser(u, GroupType.DEFAULT_FRIEND_GROUP);
		}

		// 如果是得到好友列表结束事件，返回
		if (packet.position == QQ.QQ_POSITION_FRIEND_LIST_END) {
			wake();
		} else
			main.getClient().user_GetList(packet.position);
	}

	@Override
	public void qqEvent(QQEvent e) {
		// TODO Auto-generated method stub
		switch (e.type) {
		case QQEvent.FRIEND_GET_LIST_OK:
			processGetFriendListSuccess(e);
			break;
		case QQEvent.SYS_TIMEOUT:
			switch (e.operation) {
			case QQ.QQ_CMD_GET_FRIEND_LIST:
				processGetFriendListTimeout(e);
				break;
			}
			break;
		}
	}

	/**
	 * 处理得到好友列表超时事件，我们简单得重发超时的包
	 * 
	 * @param e
	 *            QQEvent
	 */
	private void processGetFriendListTimeout(QQEvent e) {
		main.getClient().sendPacket((OutPacket) e.getSource());
	}
}
