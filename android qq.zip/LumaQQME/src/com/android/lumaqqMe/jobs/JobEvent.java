package com.android.lumaqqMe.jobs;

/**
 * 任务事件对象
 *
 * @author luma
 */
public class JobEvent {
	public IJob job;
	public String msg;

	public JobEvent(IJob job) {
		this.job = job;
		msg = "";
	}

	public JobEvent(IJob job, String msg) {
		this.job = job;
		this.msg = msg;
	}
}
