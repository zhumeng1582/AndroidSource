package com.android.lumaqqMe.jobs;

import com.android.lumaqqMe.MainShell;

/**
 * 在后台运行一些非关键任务，不需要堵塞用户操作。
 * 
 * @author luma
 */
public class BackgroundJobExecutor extends AbstractExecutor implements Runnable {

	public BackgroundJobExecutor(MainShell main) {
		// TODO Auto-generated method stub
		super(main);
		exitOnEmpty = true;
	}

	/**
	 * 运行所有任务
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			IJob job = null;
			synchronized (jobs) {
				job = jobs.poll();
				if (job == null) {
					if (exitOnEmpty)
						break;
					else {
						try {
							jobs.wait();
						} catch (InterruptedException e) {
						}
					}
				}
			}
			if (job != null)
				runJob(job);
		}

		for (IExecutorListener lis : listeners)
			lis.allCompleted();
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Thread t = new Thread(this);
		t.setName("Background Jobs");
		t.setDaemon(true);
		t.start();
	}

	@Override
	public void addJob(IJob job) {
		// TODO Auto-generated method stub
		synchronized (jobs) {
			jobs.offer(job);
			jobs.notify();
		}
	}

	private void followLink(IJob job) {
		if (job.isSuccess()) {
			// follow success link
			if (job.getSuccessLink() != null) {
				IJob linkJob = job.getSuccessLink();
				linkJob.setLinkArgument(job.getLinkArgument());
				runJob(linkJob);
			}
		} else {
			// TODO add error to error list
			if (job.getErrorString() != null) {

			}

			// follow fail link
			if (job.getFailLink() != null) {
				IJob linkJob = job.getFailLink();
				linkJob.setLinkArgument(job.getLinkArgument());
				runJob(linkJob);
			}
		}
	}

	/**
	 * 运行一个任务
	 * 
	 * @param job
	 */
	private void runJob(IJob job) {
		job.prepare(main);
		try {
			job.run(null);
		} catch (Exception e) {
		}
		job.clear();
		followLink(job);
	}

	public boolean isBlocked() {
		return false;
	}
}
