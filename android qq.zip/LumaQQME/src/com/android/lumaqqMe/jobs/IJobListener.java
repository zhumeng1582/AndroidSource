package com.android.lumaqqMe.jobs;

/**
 * 任务事件监听器
 *
 * @author luma
 */
public interface IJobListener {
	/**
	 * 任务成功时调用
	 * 
	 * @param e
	 */
	public void jobSuccess(JobEvent e);

	/**
	 * 任务失败时调用
	 * 
	 * @param e
	 */
	public void jobFailed(JobEvent e);
}
