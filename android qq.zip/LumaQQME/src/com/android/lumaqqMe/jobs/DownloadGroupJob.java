package com.android.lumaqqMe.jobs;

import java.util.ArrayList;
import java.util.List;

import com.android.lumaqqMe.MainShell;

import edu.tsinghua.lumaqq.qq.QQ;
import edu.tsinghua.lumaqq.qq.beans.DownloadFriendEntry;
import edu.tsinghua.lumaqq.qq.events.QQEvent;
import edu.tsinghua.lumaqq.qq.packets.in.DownloadGroupFriendReplyPacket;
import edu.tsinghua.lumaqq.qq.packets.in.GroupDataOpReplyPacket;

public class DownloadGroupJob extends AbstractJob {
	// 组名list和组内好友的hash，用在下载分组信息的时候，因为下载分组信息是
	// 分两部分进行的，一部分得到组名称一部分得到组的好友，光完成一部分还不
	// 行，所以需要暂时保存一下结果
	private List<String> groupNames;
	private List<DownloadFriendEntry> friends;

	// 分组好友是否已经下载完毕
	private boolean downloadGroupFriendFinished;

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		main.getClient().removeQQListener(this);
	}

	@Override
	public void prepare(MainShell m) {
		// TODO Auto-generated method stub
		super.prepare(m);
		downloadGroupFriendFinished = false;
		main.getClient().addQQListener(this);
	}

	@Override
	protected void OnQQEvent(QQEvent e) {
		// TODO Auto-generated method stub
		switch (e.type) {
		case QQEvent.FRIEND_GET_GROUP_NAMES_OK:
			processDownloadGroupNameSuccess(e);
			break;
		case QQEvent.FRIEND_DOWNLOAD_GROUPS_OK:
			processDownloadGroupFriendSuccess(e);
			break;
		case QQEvent.FRIEND_DOWNLOAD_GROUPS_FAIL:
			processDownloadGroupFriendFail(e);
			break;
		case QQEvent.SYS_TIMEOUT:
			switch (e.operation) {
			case QQ.QQ_CMD_DOWNLOAD_GROUP_FRIEND:
			case QQ.QQ_CMD_GROUP_DATA_OP:
				processDownloadGroupFriendFail(e);
				break;
			}
			break;
		}

	}

	/**
	 * 处理下载分组好友列表失败事件
	 * 
	 * @param e
	 *            QQEvent
	 */
	private void processDownloadGroupFriendFail(QQEvent e) {
		groupNames = null;
		friends = null;
		errorMessage = "job_download_group_error";
		wake();
	}

	/**
	 * 处理下载分组好友列表成功事件
	 * 
	 * @param e
	 *            QQEvent
	 */
	private void processDownloadGroupFriendSuccess(QQEvent e) {
		if (friends == null)
			friends = new ArrayList<DownloadFriendEntry>();

		DownloadGroupFriendReplyPacket packet = (DownloadGroupFriendReplyPacket) e
				.getSource();
		friends.addAll(packet.friends);
		if (packet.beginFrom == 0) {
			downloadGroupFriendFinished = true;
			if (groupNames != null)
				resetModel();
		} else {
			downloadGroupFriendFinished = false;
			main.getClient().user_DownloadGroups(packet.beginFrom);

			if (monitor != null)
				monitor.worked(10);
		}
	}

	/**
	 * 处理下载分组名称成功事件
	 * 
	 * @param e
	 *            QQEvent
	 */
	private void processDownloadGroupNameSuccess(QQEvent e) {
		GroupDataOpReplyPacket packet = (GroupDataOpReplyPacket) e.getSource();
		groupNames = packet.groupNames;
		if (downloadGroupFriendFinished && friends != null)
			resetModel();
	}

	/**
	 * 重新设置shutter的model
	 */
	private void resetModel() {
		downloadGroupFriendFinished = false;
		main.getUIHelper().resetModel(groupNames, friends);
		friends = null;
		groupNames = null;
		if (monitor != null)
			monitor.done();
		wake();
	}

	@Override
	protected void postLoop() {
		// TODO Auto-generated method stub
		super.postLoop();
	}

	@Override
	protected void preLoop() {
		// TODO Auto-generated method stub
		if (monitor != null) {
			monitor.beginTask("", 100);
			// monitor.subTask(job_download_group_1);
		}
		main.getClient().user_GetGroupNames();
		main.getClient().user_DownloadGroups(0);

		if (monitor != null)
			monitor.worked(10);
	}
	@Override
	public boolean isSuccess() {
		// TODO Auto-generated method stub
		return errorMessage != null;
	}
}
