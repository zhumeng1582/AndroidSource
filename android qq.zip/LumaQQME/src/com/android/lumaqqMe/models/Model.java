package com.android.lumaqqMe.models;

/**
 * Model基类
 * 
 * @author luma
 */
public class Model {
	protected static final String EMPTY_STRING = "";

	public Type type;
	public boolean expanded;

	/**
	 * 创建一个类型t的model
	 * 
	 * @param t
	 *            类型常量
	 */
	public Model(Type t) {
		type = t;
		expanded = false;
	}
}
