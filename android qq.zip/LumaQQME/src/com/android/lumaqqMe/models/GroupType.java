package com.android.lumaqqMe.models;

/**
 * 组类型
 * 
 * @author luma
 */
public enum GroupType {
	// 缺省好友组，比如“我的好友”组，这种组和普通好友组的区别是不需要上传组名
	DEFAULT_FRIEND_GROUP(2),
	// 普通好友组
	FRIEND_GROUP(2),
	// 陌生人组
	STRANGER_GROUP(2),
	// 黑名单组
	BLACKLIST_GROUP(2),
	// 最近联系人组
	LATEST_GROUP(0),
	// 群组
	CLUSTER_GROUP(1);

	// 组的权重
	int weight;

	GroupType(int w) {
		weight = w;
	}
}
