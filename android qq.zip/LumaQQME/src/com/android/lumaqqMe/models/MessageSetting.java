package com.android.lumaqqMe.models;

/**
 * 群消息设定
 * 
 * @author luma
 */
public enum MessageSetting {
	ACCEPT, EJECT, RECORD, BLOCK, COUNTER;
}
