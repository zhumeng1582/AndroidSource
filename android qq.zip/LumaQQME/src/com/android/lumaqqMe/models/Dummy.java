package com.android.lumaqqMe.models;

/**
 * 不表示什么，用来表示一些和QQ内容无关且不携带什么信息的model
 * 
 * @author luma
 */
public class Dummy extends Model {
	public String name;
	public DummyType dummyType;
	public Cluster cluster;

	public Dummy() {
		super(Type.DUMMY);
		initializeValues();
	}

	/**
	 * 初始化字段
	 */
	private void initializeValues() {
		name = EMPTY_STRING;
		dummyType = DummyType.CLUSTER_ORGANIZATION;
		cluster = null;
	}
}
