package com.android.lumaqqMe.models;

import edu.tsinghua.lumaqq.qq.beans.ContactInfo;
import edu.tsinghua.lumaqq.qq.beans.QQFriend;

/**
 * 这个类负责提供一些创建数据的方法，纯粹是为了免得个别的文件行数太多， 所以把这些集中操作底层数据的方法抽出来放在一个工具类里
 * 
 * @author luma
 */
public class ModelUtils {
	/**
	 * 从QQFriend类创建一个contact info结构
	 * 
	 * @param friend
	 *            QQFriend
	 * @return ContactInfo
	 */
	public static ContactInfo createContact(QQFriend friend) {
		ContactInfo ret = new ContactInfo();
		ret.nick = friend.nick;
		ret.qq = friend.qqNum;
		ret.age = friend.age;
		if (friend.isGG())
			ret.gender = "gg";
		else
			ret.gender = "mm";
		return ret;
	}

	/**
	 * 从User创建一个ContactInfo
	 * 
	 * @param u
	 *            User对象
	 * @return ContactInfo对象
	 */
	public static ContactInfo createContact(User u) {
		ContactInfo ret = new ContactInfo();
		ret.nick = u.nick;
		ret.qq = u.qq;
		ret.head = u.headId;
		return ret;
	}

	/**
	 * 从QQFriend类创建一个User
	 * 
	 * @param friend
	 *            QQFriend对象
	 * @return User
	 */
	public static User createUser(QQFriend friend) {
		User ret = new User();
		ret.headId = friend.head;
		ret.status = Status.OFFLINE;
		ret.qq = friend.qqNum;
		ret.nick = friend.nick;
		ret.displayName = ret.nick;
		ret.member = friend.isMember();
		ret.info = createContact(friend);
		ret.userFlag = friend.userFlag;
		ret.female = !friend.isGG();
		return ret;
	}
}
