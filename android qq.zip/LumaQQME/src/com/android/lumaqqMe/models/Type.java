package com.android.lumaqqMe.models;

/**
 * model类型常量
 * 
 * @author luma
 */
public enum Type {
	// model表示一个用户
	USER,
	// model表示一个群
	CLUSTER,
	// 表示一个组织
	ORGANIZATION,
	// model表示一个组
	GROUP,
	// model不表示什么，只是一种界面上的目的
	DUMMY;
}
