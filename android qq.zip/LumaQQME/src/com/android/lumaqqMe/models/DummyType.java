package com.android.lumaqqMe.models;

/**
 * Dummy model的类型
 * 
 * @author luma
 */
public enum DummyType {
	CLUSTER_ORGANIZATION, // 群内组织结构
	SUBJECTS; // 讨论组
}
