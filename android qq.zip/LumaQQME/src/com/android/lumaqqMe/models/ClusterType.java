package com.android.lumaqqMe.models;

import edu.tsinghua.lumaqq.qq.QQ;

/**
 * 群类型常量
 * 
 * @author luma
 */
public enum ClusterType {
	NORMAL, // 普通群
	DIALOG, // 多人对话
	DIALOG_CONTAINER, // 多人对话容器
	SUBJECT; // 讨论组

	public static ClusterType valueOfTemp(byte b) {
		switch (b) {
		case QQ.QQ_CLUSTER_TYPE_DIALOG:
			return DIALOG;
		case QQ.QQ_CLUSTER_TYPE_SUBJECT:
			return SUBJECT;
		default:
			return null;
		}
	}

	public byte toQQConstant() {
		switch (this) {
		case NORMAL:
			return QQ.QQ_CLUSTER_TYPE_PERMANENT;
		case DIALOG:
			return QQ.QQ_CLUSTER_TYPE_DIALOG;
		case SUBJECT:
			return QQ.QQ_CLUSTER_TYPE_SUBJECT;
		default:
			return 0;
		}
	}
}
