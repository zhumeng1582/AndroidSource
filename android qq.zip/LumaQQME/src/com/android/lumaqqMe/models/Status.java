package com.android.lumaqqMe.models;

import edu.tsinghua.lumaqq.qq.QQ;

public enum Status {
	ONLINE, AWAY, HIDDEN, OFFLINE;

	public byte toQQConstant() {
		switch (this) {
		case ONLINE:
			return QQ.QQ_STATUS_ONLINE;
		case AWAY:
			return QQ.QQ_STATUS_AWAY;
		case HIDDEN:
			return QQ.QQ_STATUS_HIDDEN;
		case OFFLINE:
			return QQ.QQ_STATUS_OFFLINE;
		default:
			return 0;
		}
	}

	public static Status valueOf(byte b) {
		switch (b) {
		case QQ.QQ_STATUS_AWAY:
			return AWAY;
		case QQ.QQ_STATUS_HIDDEN:
			return HIDDEN;
		case QQ.QQ_STATUS_OFFLINE:
			return OFFLINE;
		case QQ.QQ_STATUS_ONLINE:
			return ONLINE;
		default:
			return OFFLINE;
		}
	}
}
