package com.android.lumaqqMe;

import com.android.lumaqqMe.helpers.UIHelper;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TabHost;
import edu.tsinghua.lumaqq.qq.QQ;
import edu.tsinghua.lumaqq.qq.QQClient;
import edu.tsinghua.lumaqq.qq.Util;
import edu.tsinghua.lumaqq.qq.beans.QQUser;
import edu.tsinghua.lumaqq.qq.net.PortGateFactory;

public class MainShell extends TabActivity {
	/** Called when the activity is first created. */
	// QQ事件处理器
	private QQEventProcessor processor;
	private QQClient client;
	// Udp服务器列表
	private String[] UdpServers;
	// Tcp服务器列表
	private String[] TcpServers;
	// UI
	private UIHelper uiHelper;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		initialize();
	}

	/**
	 * 初始化变量
	 */
	private void initialize() {
		TabHost tabHost = getTabHost();
		LayoutInflater.from(this).inflate(R.layout.main_list,
				tabHost.getTabContentView(), true);
		tabHost.addTab(tabHost.newTabSpec("tab1").setIndicator("好友")
				.setContent(R.id.listGroup));
		tabHost.addTab(tabHost.newTabSpec("tab2").setIndicator("群").setContent(
				R.id.listCluster));

		client = new QQClient();
		processor = new QQEventProcessor(this);
		UdpServers = setUdpServers();
		TcpServers = setTcpServers();
		uiHelper = new UIHelper(this);
		uiHelper.initModels();
	}

	/**
	 * 设置Udp服务器列表，偷懒直接返回数组
	 */
	private String[] setUdpServers() {
		return new String[] { "sz.tencent.com", "sz2.tencent.com",
				"sz3.tencent.com", "sz4.tencent.com", "sz5.tencent.com",
				"sz6.tencent.com", "sz7.tencent.com", "61.144.238.155",
				"61.144.238.156", "202.96.170.163", "202.96.170.164",
				"219.133.38.129", "219.133.38.130", "219.133.38.43",
				"219.133.38.44", "219.133.40.215", "219.133.40.216",
				"219.133.48.100" };
	}

	/**
	 * 设置Tcp服务器列表，偷懒直接返回数组
	 */
	private String[] setTcpServers() {
		return new String[] { "tcpconn.tencent.com", "tcpconn2.tencent.com",
				"tcpconn3.tencent.com", "tcpconn4.tencent.com", "219.133.38.5",
				"218.17.209.23" };
	}

	/**
	 * 设置登录QQ
	 */
	private void setUser(int qq, String pwd) {
		client.setUser(new QQUser(qq, pwd));
	}

	/**
	 * 检查登陆状态，如果正在登录或者已经登录，直接返回，如果尚未登录则执行登录操作
	 * 
	 * @param forceRandom
	 *            true表示强制随机选择服务器
	 */
	public void checkLogin(boolean forceRandom, boolean forceTcp) {
		if (client.isLogging())
			return;

		client.setConnectionPoolFactory(new PortGateFactory());
		boolean useTcp = forceTcp;
		if (forceRandom) {
			String[] servers = useTcp ? TcpServers : UdpServers;
			client
					.setLoginServer(servers[Util.random().nextInt(
							servers.length)]);
		} else {
			if (useTcp)
				client.setLoginServer(TcpServers[0]);
			else
				client.setLoginServer(UdpServers[0]);
		}
		if (useTcp) {
			client.getUser().setUdp(false);
			client.setTcpLoginPort(80);
		} else
			client.getUser().setUdp(true);
		// 设置参数
		client.addQQListener(processor);
		try {
			// 登录
			client.login();
		} catch (Exception e1) {
			client.getUser().setStatus(QQ.QQ_STATUS_OFFLINE);
			logout();
		}
	}

	public QQClient getClient() {
		return client;
	}

	public UIHelper getUIHelper() {
		return uiHelper;
	}

	/**
	 * 使自己处于下线状态
	 */
	public void logout() {
		try {
			client.logout();
			client.release();// 释放资源，当你不使用QQ的时候
		} catch (Exception ex) {
			Log.e("error", ex.getMessage());
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		boolean result = super.onCreateOptionsMenu(menu);
		menu.add(0, C.id.LOGIN_ID, 0, R.string.menu_login);
		menu.add(0, C.id.EXIT_ID, 0, R.string.menu_exit);
		return result;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case C.id.LOGIN_ID:
			showDialog(C.id.DIALOG_LOGIN);
			return true;
		case C.id.EXIT_ID:
			logout();
			finish();
			return true;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		// TODO Auto-generated method stub
		switch (id) {
		case C.id.DIALOG_LOGIN:
			LayoutInflater factory = LayoutInflater.from(this);
			final View textEntryView = factory.inflate(
					R.layout.dialog_login_entry, null);
			return new AlertDialog.Builder(MainShell.this).setIcon(
					R.drawable.alert_dialog_icon).setTitle(
					R.string.alert_dialog_text_entry).setView(textEntryView)
					.setPositiveButton(R.string.alert_dialog_ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

									/* User clicked OK so do some stuff */
									EditText field_qqID = (EditText) textEntryView
											.findViewById(R.id.qqID);
									EditText field_qqPwd = (EditText) textEntryView
											.findViewById(R.id.qqPwd);
									int qqnum = Util.getInt(field_qqID
											.getText().toString(), -1);
									String qqpwd = field_qqPwd.getText()
											.toString();
									doLoginOk(qqnum, qqpwd);
								}
							}).setNegativeButton(R.string.alert_dialog_cancel,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

									/* User clicked cancel so do some stuff */
								}
							}).create();
		}
		return null;
	}

	private void doLoginOk(int qqnum, String qqpwd) {
		setUser(qqnum, qqpwd);
		checkLogin(false, false);
	}
}