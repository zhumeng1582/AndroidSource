package com.tencent.weibo.sdk.android.model;
/**
 * 互听好友信息
 * 
 * */
public class Firend {

 private String  nick;//互听好友昵称

 private String  name;//互听好友name
 
 private String  headurl;//互听好友头像url
public String getNick() {
	return nick;
}
public void setNick(String nick) {
	this.nick = nick;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getHeadurl() {
	return headurl;
}
public void setHeadurl(String headurl) {
	this.headurl = headurl;
} 
 
}
