package com.tencent.weibo.sdk.android.component.sso;

import java.io.Serializable;

public class WeiboToken implements Serializable{
	private static WeiboToken instance;
	private WeiboToken(){}
	public static WeiboToken getInstance(){
		if(instance == null){
			instance = new WeiboToken();
		}
		return instance;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** AccessToken */
	public String accessToken;

	/** AccessToken过期时间 */
	public long expiresIn;

	/** 用来换新的AccessToken */
	public String refreshToken;

	/** 兼容OpenID协议 */
	public String openID;

	/** OmasToken */
	public String omasToken;

	/** omasKey */
	public String omasKey;

	public String getAccessToken() {
		return accessToken;
	}


	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}


	public long getExpiresIn() {
		return expiresIn;
	}


	public void setExpiresIn(long expiresIn) {
		this.expiresIn = expiresIn;
	}


	public String getRefreshToken() {
		return refreshToken;
	}


	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}


	public String getOpenID() {
		return openID;
	}


	public void setOpenID(String openID) {
		this.openID = openID;
	}


	public String getOmasToken() {
		return omasToken;
	}


	public void setOmasToken(String omasToken) {
		this.omasToken = omasToken;
	}


	public String getOmasKey() {
		return omasKey;
	}


	public void setOmasKey(String omasKey) {
		this.omasKey = omasKey;
	}
}
