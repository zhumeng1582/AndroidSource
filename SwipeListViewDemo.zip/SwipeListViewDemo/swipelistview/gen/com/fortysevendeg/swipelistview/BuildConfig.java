/** Automatically generated file. DO NOT MODIFY */
package com.fortysevendeg.swipelistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}