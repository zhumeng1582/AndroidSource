/** Automatically generated file. DO NOT MODIFY */
package com.fortysevendeg.android.swipelistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}