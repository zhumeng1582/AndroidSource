## 介绍

一个 AVOS Cloud 综合型的 Demo，目前做的不够细致，请谅解，演示了大多数功能:

* 用户系统
* 文件上传下载
* 子类化
* 对象复杂查询等

需要您通过查看代码来学习。


## 如何运行

* 导入本工程到 Eclipse
* 右键点击项目，运行 `Run As -> Android Application`即可看到。

## 替换 App 信息

Demo 使用的是公共的 app id 和 app key，您可以在`com.example.avoscloud_demo.DemoGroupActivity`修改成您自己的应用 id 和 key。
