package com.example.avoscloud_demo;

/**
 * Created by lzw on 14-8-24.
 */
public class Config {
   public static String APP_ID ="gqd0m4ytyttvluk1tnn0unlvmdg8h4gxsa2ga159nwp85fks";
   public static String APP_KEY ="7gd2zom3ht3vx6jkcmaamm1p2pkrn8hdye2pn4qjcwux1hl1";
}
