package com.vanceinfo.qq;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.LinearLayout;
import android.widget.SimpleExpandableListAdapter;
import android.widget.TextView;

public class QQExpandableListViewActivity extends Activity {
	private static ArrayList<Map<String, String>> parentData = new ArrayList<Map<String, String>>();
	private static ArrayList<ArrayList<Map<String, String>>> childData = new ArrayList<ArrayList<Map<String, String>>>();
	private ExpandableListView elistview;
	private TextView tv;
	/**
	 * ��ǰ�򿪵ĸ��ڵ�
	 */
	private int the_group_expand_position = -1;
	/**
	 * �򿪵ĸ��ڵ�������ӽڵ���
	 */
	private int position_child_count = 0;
	/**
	 * �Ƿ��д򿪵ĸ��ڵ�
	 */
	private boolean isExpanding = false;

	public void getData() {
		for (int i = 0; i < 5; i++) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("parend", i + "");
			parentData.add(map);
		}
		for (int i = 0; i < 15; i++) {
			ArrayList<Map<String, String>> child = new ArrayList<Map<String, String>>();
			for (int j = 0; j < 15; j++) {
				Map<String, String> map = new HashMap<String, String>();
				map.put("child", i + "" + j);
				child.add(map);
			}
			childData.add(child);
		}
	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		elistview = (ExpandableListView) findViewById(R.id.qq_listview);
		// �滻ExpandableListView�Ĵ򿪹ر�ʱ�ļ�ͷͼ��
		elistview.setGroupIndicator(this.getResources().getDrawable(
				R.drawable.selector));
		// ����ʱ��ʾ�ĸ��ڵ�
		tv = (TextView) findViewById(R.id.qq_list_textview);

		/**
		 * �������б�ʱ���Ϸ���ʾ���ڵ��view
		 */
		final LinearLayout linear = (LinearLayout) findViewById(R.id.gone_linear);

		/**
		 * �������ڵ�򿪵��¼�
		 */
		elistview.setOnGroupExpandListener(new OnGroupExpandListener() {
			@Override
			public void onGroupExpand(int groupPosition) {
				the_group_expand_position = groupPosition;
				position_child_count = childData.get(groupPosition).size();
				// if(linear.getVisibility()==View.GONE){
				// linear.setVisibility(View.VISIBLE);
				// }
				isExpanding = true;
			}

		});

		/**
		 * �������ڵ�رյ��¼�
		 */
		elistview.setOnGroupCollapseListener(new OnGroupCollapseListener() {
			@Override
			public void onGroupCollapse(int groupPosition) {
				if (linear.getVisibility() == View.VISIBLE) {
					linear.setVisibility(View.GONE);
				}
				isExpanding = false;
			}

		});

		linear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				linear.setVisibility(View.GONE);
				elistview.collapseGroup(the_group_expand_position);
			}

		});

		/**
		 * ͨ��setOnScrollListener�������б����»���ʱitem��ʾ����ʧ���¼�
		 */

		elistview.setOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {

			}

			@Override
			// firstVisibleItem����Ļ�е�һ����ʾ��������adapter�е�λ��,visibleItemCount ������Ļ�����һ��������adapter�е�����,totalItemCount����adapter�е�������!

			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				// �����ڵ��ʱִ��
				if (isExpanding) {
					// ����ǰ��һ��item idС�ڴ򿪵ĸ��ڵ�id ����ڴ򿪵ĸ��ڵ�id�������ӽڵ�����֮��ʱ
					if (firstVisibleItem <= the_group_expand_position
							|| firstVisibleItem > (the_group_expand_position + position_child_count)) {

						linear.setVisibility(View.GONE);
						System.out.println(firstVisibleItem
								+ "******************");
						System.out.println(the_group_expand_position
								+ "******************111111");

					} else {
						
						
						
						linear.setVisibility(View.VISIBLE);
						tv.setText(((Map) parentData
								.get(the_group_expand_position)).get("parend")
								.toString());
						System.out.println(firstVisibleItem
								+ "******************22222222");
						System.out.println(the_group_expand_position
								+ "******************33333333333333333");
						
					}
				}
			}

		});

		getData();

		SimpleExpandableListAdapter selAdapter = new SimpleExpandableListAdapter(
				this, parentData, R.layout.qqlistparent,
				new String[] { "parend" }, new int[] { R.id.parend },
				childData, R.layout.qqlistchild, new String[] { "child" },
				new int[] { R.id.child });
		elistview.setAdapter(selAdapter);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onStop()
	 */
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Log.e("=======", "onStop");
		parentData.clear();
		childData.clear();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onDestroy()
	 */
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.e("=======", "onDestry");
	}
	
	

}