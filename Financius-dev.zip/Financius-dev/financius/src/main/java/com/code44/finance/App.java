package com.code44.finance;

import android.content.Context;
import android.support.multidex.MultiDexApplication;

import net.danlew.android.joda.JodaTimeAndroid;

import dagger.ObjectGraph;
import hugo.weaving.DebugLog;

public class App extends MultiDexApplication {
    private ObjectGraph objectGraph;

    public static App with(Context context) {
        return (App) context.getApplicationContext();
    }

    @Override public void onCreate() {
        super.onCreate();
//        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
//                .detectAll()
//                .penaltyLog()
//                .penaltyDialog()
//                .build());
//        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
//                .detectAll()
//                .penaltyDeath()
//                .penaltyLog()
//                .build());
        buildObjectGraphAndInject();
        JodaTimeAndroid.init(this);
    }

    @DebugLog public void buildObjectGraphAndInject() {
        objectGraph = ObjectGraph.create(Modules.list(this));
        objectGraph.inject(this);
    }

    public void inject(Object o) {
        objectGraph.inject(o);
    }
}
