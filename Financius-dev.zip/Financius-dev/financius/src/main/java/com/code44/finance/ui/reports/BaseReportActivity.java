package com.code44.finance.ui.reports;

import com.code44.finance.ui.DrawerActivity;

public abstract class BaseReportActivity extends DrawerActivity {
}
