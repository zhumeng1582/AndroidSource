package com.code44.finance.ui.reports;

import com.code44.finance.ui.BaseFragment;

public abstract class BaseReportFragment extends BaseFragment {
}
