package com.code44.finance.backend.endpoint.body;

public interface Body {
}
