package com.example.griddemo;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalFocusChangeListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private GridView gridView;
	private BottomAdapter adapter;
	private HorizontalScrollView scrollView;
	// �������� ��GridView�ƶ������Ҷ�
	private static final int select_test = 20;
	// ÿ��GridView Item�Ŀ���
	private static final int WIDTH = 50;
	// ƥ�������
	private static final int[] alls = { R.drawable.icon_filter_01,
			R.drawable.icon_filter_02, R.drawable.icon_filter_03,
			R.drawable.icon_filter_04, R.drawable.icon_filter_06,
			R.drawable.icon_filter_07, R.drawable.icon_filter_08,
			R.drawable.icon_filter_09, R.drawable.icon_filter_10,
			R.drawable.icon_filter_11, R.drawable.icon_filter_12,
			R.drawable.icon_filter_13, R.drawable.icon_filter_14,
			R.drawable.icon_filter_15, R.drawable.icon_filter_16,
			R.drawable.icon_filter_17, R.drawable.icon_filter_18_on,
			R.drawable.icon_filter_18, };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		scrollView = (HorizontalScrollView) findViewById(R.id.home_scroll);

		gridView = (GridView) findViewById(R.id.home_grid);
		adapter = new BottomAdapter(MainActivity.this, alls);
		gridView.setAdapter(adapter);

		// ��������ú���Ҫ gridViewֻ��ˮƽ����
		gridView.setNumColumns(adapter.getCount());

		// �鿴Դ���� gridViewֻ��֧�����򻬶�,ֻ����ˮƽ����
		// gridView.smoothScrollTo((WIDTH + 1) * select_test, 0);

		// ���ֱ��ʹ��smoothScrollTo() gridView�����ܻ���(�����϶�)
		// scrollView.smoothScrollTo((WIDTH + 1) * select_test, 0);

		scrollView.getViewTreeObserver().addOnGlobalFocusChangeListener(
				new OnGlobalFocusChangeListener() {

					@Override
					public void onGlobalFocusChanged(View oldFocus,
							View newFocus) {
						// Ҳ����ʹ��ScrollTo()���� ��smoothScrollTo()��������ȫ

						scrollView.smoothScrollTo((WIDTH + 1) * select_test, 0);
						// ����Activity��gridView���Զ����� �ƶ������Լ�����
					}
				});
	}

	class BottomAdapter extends BaseAdapter {
		private Context context;
		private int[] images;
		private ImageView imageView;

		public BottomAdapter(Context context, int[] images) {
			this.context = context;
			this.images = images;
		}

		@Override
		public int getCount() {
			return images.length;
		}

		@Override
		public Object getItem(int position) {
			return images[position];
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			if (convertView == null) {
				imageView = new ImageView(context);
			} else {
				imageView = (ImageView) convertView;
			}
			imageView.setImageResource(images[position]);
			return imageView;
		}
	}
}