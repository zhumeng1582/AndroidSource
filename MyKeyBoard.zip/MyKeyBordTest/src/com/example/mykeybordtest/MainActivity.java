package com.example.mykeybordtest;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.mykeybordtest.KeyboardUtil.InputFinishListener;

public class MainActivity extends Activity {
	private Context ctx;
	private Activity act;
	LinearLayout layout_input;
	public static SharedPreferences appInfoSp;
	public static SharedPreferences.Editor appInfoSpEditor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		ctx = this;
		act = this;
		layout_input = (LinearLayout) findViewById(R.id.layout_input);
		final KeyboardUtil keyBoard = new KeyboardUtil(this, this, layout_input, new InputFinishListener() {

			@Override
			public void inputHasOver(String text) {
				Toast.makeText(MainActivity.this, "输入完成:" + text, Toast.LENGTH_LONG).show();
			}
		});
		layout_input.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				keyBoard.showKeyboard();
				return false;
			}
		});
		appInfoSp = getSharedPreferences("share", Context.MODE_PRIVATE);
		appInfoSpEditor = appInfoSp.edit();
		Log.e("", ""+appInfoSp.getString("test", "aaa"));
	}

}
