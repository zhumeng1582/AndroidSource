/** Automatically generated file. DO NOT MODIFY */
package com.example.mykeybordtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}