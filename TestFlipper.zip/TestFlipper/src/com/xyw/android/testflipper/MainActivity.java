package com.xyw.android.testflipper;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ViewFlipper;

public class MainActivity extends Activity {

	private ViewFlipper vf = null;
	private ImageButton rightBtn, leftBtn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		vf = (ViewFlipper) findViewById(R.id.vf);
		vf.startFlipping();
		vf.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.out.println(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right)+"-"+AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left)+AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right1)+"-"+AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left1)+"-"+vf.getInAnimation()+"-"+vf.getOutAnimation());
				if (vf.getInAnimation() == AnimationUtils.loadAnimation(
						getApplicationContext(), R.anim.right)) {
					vf.setOutAnimation(getApplicationContext(), R.anim.right1);
					vf.setInAnimation(getApplicationContext(), R.anim.left1);
					System.out.println(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right));
					vf.showPrevious();
				} else {
					vf.setOutAnimation(getApplicationContext(), R.anim.left);
					vf.setInAnimation(getApplicationContext(), R.anim.right);
					vf.showPrevious();
				}
				if (!vf.isFlipping())
					vf.startFlipping();

			}
		});
		leftBtn = (ImageButton) findViewById(R.id.leftBtn);
		leftBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				vf.setOutAnimation(getApplicationContext(), R.anim.left);
				vf.setInAnimation(getApplicationContext(), R.anim.right);
				vf.showNext();
				vf.stopFlipping();
			}
		});
		rightBtn = (ImageButton) findViewById(R.id.rightBtn);
		rightBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				vf.setOutAnimation(getApplicationContext(), R.anim.right1);
				vf.setInAnimation(getApplicationContext(), R.anim.left1);
				vf.showPrevious();
				vf.stopFlipping();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
