/** Automatically generated file. DO NOT MODIFY */
package com.xyw.android.testflipper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}