/** Automatically generated file. DO NOT MODIFY */
package com.max.test.gridview_viewpager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}