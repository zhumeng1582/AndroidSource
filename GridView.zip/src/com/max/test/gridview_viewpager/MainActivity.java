package com.max.test.gridview_viewpager;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout.LayoutParams;

public class MainActivity extends Activity {
	HorizontalScrollView horizontalScrollView;
	GridView gridView;
	DisplayMetrics dm;
	private int NUM = 4; // ÿ����ʾ����
	private int hSpacing = 20;// ˮƽ���

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		horizontalScrollView = (HorizontalScrollView) findViewById(R.id.scrollView);
		gridView = (GridView) findViewById(R.id.gridView1);

		horizontalScrollView.setHorizontalScrollBarEnabled(false);// ���ع�����
		getScreenDen();
		setValue();
	}

	private void setValue() {
		MyGridViewAdapter adapter = new MyGridViewAdapter(this, 21);
		gridView.setAdapter(adapter);
		LayoutParams params = new LayoutParams(adapter.getCount() * 65,
				LayoutParams.WRAP_CONTENT);
		gridView.setLayoutParams(params);
		gridView.setColumnWidth(dm.widthPixels / NUM);
		// gridView.setHorizontalSpacing(hSpacing);
		gridView.setStretchMode(GridView.NO_STRETCH);
		int count = adapter.getCount();
		gridView.setNumColumns((count % 2 == 0) ? count / 2 : count / 2 + 1);
	}

	private void getScreenDen() {
		dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
