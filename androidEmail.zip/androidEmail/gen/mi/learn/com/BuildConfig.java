/** Automatically generated file. DO NOT MODIFY */
package mi.learn.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}