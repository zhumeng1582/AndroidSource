Multi-check-in-expandablelistview
=================================
![image](https://raw.github.com/swingseagull/Multi-check-in-expandablelistview/master/multicheck-expandablelistview.png)