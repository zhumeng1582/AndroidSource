/** Automatically generated file. DO NOT MODIFY */
package com.tencent.tauthdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}