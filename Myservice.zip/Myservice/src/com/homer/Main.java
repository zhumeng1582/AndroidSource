package com.homer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.homer.bind.PlayBindMusic;
import com.homer.receiver.PlayMusicRecevicer;
import com.homer.remote.PlayRemoteMusic;
import com.homer.service.PlayMusicService;

public class Main extends Activity implements OnClickListener {

	private Button musicServiceBtn;
	private Button musicReceiverBtn;
	private Button bindMusicServiceBtn;
	private Button remoteMusicServiceBtn;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		musicServiceBtn = (Button) findViewById(R.id.musicService);
		musicReceiverBtn = (Button) findViewById(R.id.musicReceiver);
		bindMusicServiceBtn = (Button) findViewById(R.id.bindMusicService);
		remoteMusicServiceBtn = (Button) findViewById(R.id.remoteMusicService);
		
		musicServiceBtn.setOnClickListener(this);
		musicReceiverBtn.setOnClickListener(this);
		bindMusicServiceBtn.setOnClickListener(this);
		remoteMusicServiceBtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.musicService:
			startActivity(new Intent(this, PlayMusicService.class));
			break;

		case R.id.musicReceiver:
			startActivity(new Intent(this, PlayMusicRecevicer.class));
			break;

		case R.id.bindMusicService:
			startActivity(new Intent(this, PlayBindMusic.class));
			break;

		case R.id.remoteMusicService:
			startActivity(new Intent(this, PlayRemoteMusic.class));
			break;
		}
	}

}