package com.qyh.main;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.EditText;

public class DigitKeyPadUtil {
	public static void showPassWdPadView(final EditText tv, final Context context,
			final View digitView) {
				// ��һ����ͼ���������Ӧ�ó���֮��
				final WindowManager windowmanager = (WindowManager) context
						.getSystemService(Context.WINDOW_SERVICE);
				LayoutParams layoutparams = new LayoutParams(400, 550,
						WindowManager.LayoutParams.FIRST_SUB_WINDOW,
						WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
						PixelFormat.RGBA_8888);
				layoutparams.gravity = Gravity.LEFT;
				layoutparams.x = 200;
				layoutparams.y = 500;

				Button btn = (Button) digitView
						.findViewById(R.id.digitkeypad_ok);
				final EditText digitkeypad_edittext = (EditText) digitView
						.findViewById(R.id.digitpadedittext);
				btn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						String str = digitkeypad_edittext.getText().toString();
						tv.setText(str);
						if (digitView.getParent() != null) {
							windowmanager.removeView(digitView);
						}
					}
				});

				if (digitView.getParent() == null) {
					windowmanager.addView(digitView, layoutparams);
				}
				// LayoutInflater mLayoutInflater = (LayoutInflater)
				// getSystemService(LAYOUT_INFLATER_SERVICE);
				// �Զ��岼��
				// final PopupWindow mPop = new PopupWindow(passwdview,
				// LayoutParams.WRAP_CONTENT,
				// LayoutParams.WRAP_CONTENT, true);
				// mPop.setContentView(passwdview);//���ð�����ͼ
				// mPop.setWidth(300);
				// mPop.setHeight(400);//���õ������С
				// mPop.setOutsideTouchable(false);
				// mPop.showAsDropDown(editText);
				//
				// Button btn = (Button)
				// passwdview.findViewById(R.id.digitkeypad_ok);
				// final EditText digitkeypad_edittext = (EditText)
				// passwdview.findViewById(R.id.digitpadedittext);
				// btn.setOnClickListener(new OnClickListener() {
				//
				// @Override
				// public void onClick(View arg0) {
				// String str = digitkeypad_edittext.getText().toString();
				// editText.setText(str);
				// mPop.dismiss();
				// }
				// });
	}

}
