package com.qyh.main;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
 
public class AndroidInputNumberActivity extends Activity {
    private DigitPasswordKeyPad dpk;
    private View digitView;
    private Context content ;
    EditText editText;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        content = this;
        
        dpk = new DigitPasswordKeyPad(this);
        digitView = dpk.setup();
        
        editText = (EditText)findViewById(R.id.input);
        editText.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
            	DigitKeyPadUtil.showPassWdPadView((EditText)v,content,digitView);
            }
        });
    }
    

}
