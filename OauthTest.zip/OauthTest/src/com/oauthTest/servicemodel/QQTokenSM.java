package com.oauthTest.servicemodel;

public class QQTokenSM {
	public String access_token;
	public String expires_in;
	public String openid;
	@Override
	public String toString() {
		return "QQTokenSM [access_token=" + access_token + ", expires_in="
				+ expires_in + ", openid=" + openid + "]";
	}
}
