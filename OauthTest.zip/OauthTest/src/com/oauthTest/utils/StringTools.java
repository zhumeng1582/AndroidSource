package com.oauthTest.utils;


public class StringTools {
	public static boolean isEmpty(String msg) {
		return msg == null || "".equals(msg);
	}
}
